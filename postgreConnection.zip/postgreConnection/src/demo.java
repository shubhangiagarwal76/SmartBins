import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import  java.sql.ResultSet;


public class demo {
    public static  void main(String args[])
    {
        try{
            Class.forName("org.postgresql.Driver");
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/SmartBins", "postgres", "behenchod101");
            PreparedStatement driver = con.prepareStatement("select * from public.\"Driver\"");
            PreparedStatement staff = con.prepareStatement("select * from public.\"Staff\"");
            PreparedStatement dustbin = con.prepareStatement("select * from public.\"Dustbin\"");
            PreparedStatement location = con.prepareStatement("select * from public.\"Location\"");
            ResultSet rs = driver.executeQuery();
            ResultSet rs1 = staff.executeQuery();
            ResultSet d1 = dustbin.executeQuery();
            ResultSet l1 = location.executeQuery();
            System.out.println("Drivers Table is");
            while (rs.next()){
                System.out.println(rs.getLong(1)+" "+rs.getLong(2)+" "+ rs.getString(3)+" "+rs.getString(4)+ " "+rs.getLong(5)+" "+rs.getLong(6)+" "+rs.getString(7));
            }
            System.out.println("Staff table is");
            while ((rs1.next()))
            {
                System.out.println(rs1.getLong(1)+" "+rs1.getString(2)+" "+rs1.getString(3)+" "+rs1.getLong(4)+" "+rs1.getLong(5)+" "+rs1.getString(6));
            }
            System.out.println("Dustbin Table is");
            while ((d1.next()))
            {
                System.out.println(d1.getLong(1)+" "+d1.getLong(2)+ " "+ d1.getInt(3));
            }
            System.out.println("Location table is");
            while (l1.next())
            {
                System.out.println(l1.getLong(1)+" "+l1.getLong(2)+" "+l1.getLong(3)+" "+l1.getString(4));
            }

        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }
}

